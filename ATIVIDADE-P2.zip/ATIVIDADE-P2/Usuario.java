public abstract class Usuario {
  public abstract void enviaAbraco(Usuario receiver);
  public abstract void recebeAbraco(Usuario usuario);
  public abstract void imprimeInformacoes();
}