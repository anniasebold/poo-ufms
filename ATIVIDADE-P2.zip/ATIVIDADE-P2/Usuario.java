public abstract class Usuario {
  public abstract void enviarAbracoAfinidade();
  public abstract void enviarAbracoSemAfinidade();
  public abstract void receberAbracoAfinidade();
  public abstract void receberAbracoSemAfinidade();
  public abstract void imprimeInformacoes();
}