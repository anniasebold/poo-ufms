public interface Comportamento {
  public void machucar(SuperHeroi heroi);
  public void ajudar(SuperHeroi heroi);
}