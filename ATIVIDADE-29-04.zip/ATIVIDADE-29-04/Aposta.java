public class Aposta {
  private double valor;

  public Aposta(double valor) {
    setValor(valor);
  }

  public double getValor() {
    return this.valor;
  }

  public void setValor(double valor) {
    this.valor = valor;
  }

}