public class Main {
  Veiculo v = new Veiculo(1200);
  VeiculoTerrestre vt = new VeiculoTerrestre(1900, true);
  Tanque t = new Tanque(1000, true, "20/08/2001");
  
}